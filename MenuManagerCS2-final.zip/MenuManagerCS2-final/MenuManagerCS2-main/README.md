# Info

MenuManager main repository

CSDevs topic: https://csdevs.net/resources/menumanager.726/ (There is all info about buttons, config, demo and etc.)


MenuManagerCore - main core plugin

MenuManagerApi - api lib project

MenuManagerText - just an example how to use this plugin
